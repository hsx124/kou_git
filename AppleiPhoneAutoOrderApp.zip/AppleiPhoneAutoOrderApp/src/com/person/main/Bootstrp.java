package com.person.main;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HttpContext;

public class Bootstrp {
	protected HttpHost proxy;

	private HttpResponse getAtb(HttpClientContext httpClientContext) throws Exception {
		String url = "https://www.apple.com/jp/shop/beacon/atb";
		HttpGet httpRequest = getHttpGet(url);

		httpRequest.addHeader((Header) new BasicHeader("Accept", "*/*"));
		httpRequest.addHeader((Header) new BasicHeader("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3"));
		httpRequest.addHeader((Header) new BasicHeader("Origin", getOrignal(url)));
		httpRequest.addHeader((Header) new BasicHeader("Upgrade-Insecure-Requests", "1"));
		httpRequest.addHeader(
				(Header) new BasicHeader("Referer", "https://www.apple.com/jp/shop/buy-iphone/iphone-13-pro"));
		httpRequest.addHeader((Header) new BasicHeader("sec-ch-ua",
				"\"Chromium\";v=\"110\", \"Not A(Brand\";v=\"24\", \"Google Chrome\";v=\"110\""));
		httpRequest.addHeader((Header) new BasicHeader("sec-ch-ua-mobile", "?0"));
		httpRequest.addHeader((Header) new BasicHeader("sec-ch-ua-platform", "\"Windows\""));
		httpRequest.addHeader((Header) new BasicHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"));
		httpRequest.addHeader((Header) new BasicHeader("Cache-Control", "no-cache"));
		httpRequest.addHeader((Header) new BasicHeader("Pragma", "no-cache"));

		httpRequest.addHeader((Header) new BasicHeader("Cookie", "as_sfa=" + (String) this.appKeyMap.get("assfa")));

		HttpResponse httpResponse = proxyClient.execute((HttpRequestBase) httpRequest, httpClientContext);

		return httpResponse;
	}

	public HttpGet getHttpGet(String uri) {
		RequestConfig requestConfig = createRequestConfig();
		HttpGet method = new HttpGet(uri);
		method.setConfig(requestConfig);
		return method;
	}

	private RequestConfig createRequestConfig() {
		if (this.proxy == null) {
			return RequestConfig.custom().setConnectTimeout(10000).setConnectionRequestTimeout(10000)
					.setSocketTimeout(10000).setExpectContinueEnabled(false).setCookieSpec("standard").build();
		}
		return RequestConfig.custom().setConnectTimeout(10000).setConnectionRequestTimeout(10000)
				.setSocketTimeout(10000).setExpectContinueEnabled(false).setCookieSpec("standard").setProxy(this.proxy)
				.build();
	}

	public static String getOrignal(String url) {
		Pattern pattern1 = Pattern.compile("[\\s\\S]*.com/");
		Matcher matcher1 = pattern1.matcher(url);
		if (matcher1.find()) {
			return matcher1.group(0).replace(".com/", ".com");
		}
		return "";
	}

	public HttpResponse execute(HttpRequestBase request, HttpClientContext httpClientContext) throws Exception {
		return (HttpResponse) httpClient.execute((HttpUriRequest) request, (HttpContext) httpClientContext);
	}
}
