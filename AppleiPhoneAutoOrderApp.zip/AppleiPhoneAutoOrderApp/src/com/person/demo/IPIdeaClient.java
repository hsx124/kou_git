package com.person.demo;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClients;

public class IPIdeaClient extends ProxyClient {
	public IPIdeaClient(HttpHost proxy) {
		this.proxy = proxy;
		BasicCredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
		basicCredentialsProvider.setCredentials(new AuthScope(proxy),
				(Credentials) new UsernamePasswordCredentials("hsx19900829", "Hsx19900829"));
		this.httpClient = HttpClients.custom().setKeepAliveStrategy(this.defaultStrategy)
				.setDefaultCredentialsProvider((CredentialsProvider) basicCredentialsProvider)
				.setDefaultSocketConfig(this.socketConfig).setConnectionManager((HttpClientConnectionManager) this.cm)
				.setRetryHandler(this.httpRequestRetryHandler).build();
	}

	public IPIdeaClient(String username, String password) {
		this.proxy = new HttpHost("ipinfo.ipidea.io", 2336, "https");
		BasicCredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
		basicCredentialsProvider.setCredentials(new AuthScope(this.proxy),
				(Credentials) new UsernamePasswordCredentials(username, password));
		this.httpClient = HttpClients.custom().setKeepAliveStrategy(this.defaultStrategy)
				.setDefaultCredentialsProvider((CredentialsProvider) basicCredentialsProvider)
				.setDefaultSocketConfig(this.socketConfig).setConnectionManager((HttpClientConnectionManager) this.cm)
				.setRetryHandler(this.httpRequestRetryHandler).build();
	}
}