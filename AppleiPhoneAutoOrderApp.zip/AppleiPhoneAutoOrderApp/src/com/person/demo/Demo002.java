package com.person.demo;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Random;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import okhttp3.Credentials;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class Demo002 {
	public static void main(String[] args) throws Exception {
		String string = getRandomString(6);
		//		testWithOkHttp();
		String url = "https://ipinfo.ipidea.io";
		HttpClient httpClient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet("http://33dd-240d-1a-664-4900-f81b-a5cb-bc5b-c241.ngrok-free.app/GetProxyIp/IpServlet");
		//使用代理服务器
		HttpHost httpHost = new HttpHost("proxy.ipidea.io", 2336);
		
		CredentialsProvider provider = new BasicCredentialsProvider();
		provider.setCredentials(new AuthScope(httpHost),
				new UsernamePasswordCredentials("hsx19900829-zone-custom-session-133m4zx2r-sessTime-2", "Hsx19900829"));
		CloseableHttpClient Client = HttpClients.custom().setDefaultCredentialsProvider(provider).build();
		RequestConfig config = RequestConfig.custom().setProxy(httpHost).build();
		httpGet.setConfig(config);
		CloseableHttpResponse response = (CloseableHttpResponse) Client.execute(httpGet);
		HttpEntity entity = response.getEntity();
		//输出网页内容
		System.out.println("网页内容:");
		System.out.println(EntityUtils.toString(entity, "utf-8"));
		response.close();
		
//		HttpGet request = new HttpGet("http://localhost:8080/GetProxyIp/IpServlet");
//		/*  515 */       HttpResponse httpResponse = ((HttpClient) request).execute((HttpRequestBase)request);
//		/*  516 */       String responseStr = EntityUtils.toString(httpResponse.getEntity());
//		/*  517 */       JSONObject jsonObject = new JSONObject(responseStr);
//		System.out.println(jsonObject.toString());

	}

	public static String getRandomString(int length) {
		String str = "abcdefghijklmnopqrstuvwxyz0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(str.length());
			sb.append(str.charAt(number));
		}
		return sb.toString();
	}

	public static void testWithOkHttp() throws IOException {
		String url = "https://ipinfo.ipidea.io";
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("proxy.ipidea.io", 2336));
		OkHttpClient client = new OkHttpClient().newBuilder().proxy(proxy).proxyAuthenticator((route, response) -> {
			String credential = Credentials.basic(
					"hsx19900829-zone-custom-session-133" + getRandomString(6) + "-sessTime-2",
					"Hsx19900829");
			return response.request().newBuilder()
					.header("Proxy-Authorization", credential)
					.build();
		}).build();

		Request request = new Request.Builder().url(url).build();
		okhttp3.Response response = client.newCall(request).execute();
		String responseString = response.body().string();
		System.out.println(responseString);
	}
}
