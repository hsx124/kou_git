package com.person.demo;

import java.io.IOException;

import org.apache.http.HeaderElement;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HttpContext;

public class ProxyClient {
	protected PoolingHttpClientConnectionManager cm = null;

	protected SocketConfig socketConfig = null;

	protected CloseableHttpClient httpClient = null;
	protected HttpHost proxy;
	protected HttpRequestRetryHandler httpRequestRetryHandler;
	protected ConnectionKeepAliveStrategy defaultStrategy;

	public ProxyClient() {
		this.cm = new PoolingHttpClientConnectionManager();
		this.cm.setDefaultMaxPerRoute(500);
		this.cm.setMaxTotal(1000);

		this.socketConfig = SocketConfig.custom().setSoTimeout(10000).build();

		this.httpRequestRetryHandler = new HttpRequestRetryHandler() {
			public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
				if (executionCount > 1) {
					return false;
				}
				if (exception instanceof org.apache.http.NoHttpResponseException) {
					return true;
				}
				if (exception instanceof java.io.InterruptedIOException) {
					return false;
				}
				if (exception instanceof java.net.UnknownHostException) {
					return false;
				}
				if (exception instanceof org.apache.http.conn.ConnectTimeoutException) {
					return false;
				}
				HttpClientContext clientContext = HttpClientContext.adapt(context);
				HttpRequest request = clientContext.getRequest();

				if (!(request instanceof org.apache.http.HttpEntityEnclosingRequest)) {
					return true;
				}
				return false;
			}
		};

		this.defaultStrategy = new ConnectionKeepAliveStrategy() {
			public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
				BasicHeaderElementIterator basicHeaderElementIterator = new BasicHeaderElementIterator(
						response.headerIterator("Keep-Alive"));
				while (basicHeaderElementIterator.hasNext()) {
					HeaderElement he = basicHeaderElementIterator.nextElement();
					String param = he.getName();
					String value = he.getValue();
					if (value != null && param.equalsIgnoreCase("timeout")) {
						return Long.parseLong(value) * 1000L;
					}
				}
				return 65000L;
			}
		};
		this.httpClient = HttpClients.custom().setKeepAliveStrategy(this.defaultStrategy)
				.setConnectionManager((HttpClientConnectionManager) this.cm).setDefaultSocketConfig(this.socketConfig)
				.setRetryHandler(this.httpRequestRetryHandler).build();
	}

	private RequestConfig createRequestConfig() {
		if (this.proxy == null) {
			return RequestConfig.custom().setConnectTimeout(10000).setConnectionRequestTimeout(10000)
					.setSocketTimeout(10000).setExpectContinueEnabled(false).setCookieSpec("standard").build();
		}
		return RequestConfig.custom().setConnectTimeout(10000).setConnectionRequestTimeout(10000)
				.setSocketTimeout(10000).setExpectContinueEnabled(false).setCookieSpec("standard").setProxy(this.proxy)
				.build();
	}

	public HttpGet getHttpGet(String uri) {
		RequestConfig requestConfig = createRequestConfig();
		HttpGet method = new HttpGet(uri);
		method.setConfig(requestConfig);
		return method;
	}

	public HttpPost getHttpPost(String uri) {
		RequestConfig requestConfig = createRequestConfig();
		HttpPost method = new HttpPost(uri);
		method.setConfig(requestConfig);
		return method;
	}

	public HttpResponse execute(HttpRequestBase request, HttpClientContext httpClientContext) throws Exception {
		return (HttpResponse) this.httpClient.execute((HttpUriRequest) request, (HttpContext) httpClientContext);
	}

	public HttpResponse execute(HttpRequestBase request) throws Exception {
		return (HttpResponse) this.httpClient.execute((HttpUriRequest) request);
	}
}