package com.person.demo;

import java.util.Random;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class Demo001 {
	private static ProxyClient proxy = new ProxyClient();

	public static void main(String[] args) throws Exception {
		//		HttpClientContext httpClientContext = HttpClientContext.create();
		//		HttpResponse httpResponse0 = initApple(httpClientContext);
		//		String responseStr = EntityUtils.toString(httpResponse0.getEntity());
		//		System.out.println(responseStr);
		String ipIdeaRandomStr = getRandomString(6);
		IPIdeaClient iPIdeaClient = new IPIdeaClient(
				"hsx19900829-zone-custom-session-133" + ipIdeaRandomStr + "-sessTime-2", "Hsx19900829");
		ProxyClient proxyClient = iPIdeaClient;
		HttpGet request = proxyClient.getHttpGet("http://lumtest.com/myip.json");
		HttpResponse httpResponse = proxyClient.execute((HttpRequestBase) request);
		String responseStr = EntityUtils.toString(httpResponse.getEntity());
		JSONObject jsonObject = new JSONObject(responseStr);
		System.out.println(jsonObject.getString("ip"));
	}

	public static String getRandomString(int length) {
		String str = "abcdefghijklmnopqrstuvwxyz0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(str.length());
			sb.append(str.charAt(number));
		}
		return sb.toString();
	}

	private static HttpResponse initApple(HttpClientContext httpClientContext) throws Exception {
		HttpGet httpRequest = proxy.getHttpGet("https://www.apple.com/jp/shop/buy-iphone/iphone-14-pro/");

		httpRequest.addHeader((Header) new BasicHeader("Accept", "*/*"));
		httpRequest.addHeader((Header) new BasicHeader("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3"));
		httpRequest.addHeader(
				(Header) new BasicHeader("Origin", "https://www.apple.com/jp/shop/buy-iphone/iphone-14-pro/"));
		httpRequest.addHeader((Header) new BasicHeader("Upgrade-Insecure-Requests", "1"));
		httpRequest.addHeader((Header) new BasicHeader("sec-ch-ua",
				"\"Chromium\";v=\"110\", \"Not A(Brand\";v=\"24\", \"Google Chrome\";v=\"110\""));
		httpRequest.addHeader((Header) new BasicHeader("sec-ch-ua-mobile", "?0"));
		httpRequest.addHeader((Header) new BasicHeader("sec-ch-ua-platform", "\"Windows\""));
		httpRequest.addHeader((Header) new BasicHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"));
		httpRequest.addHeader((Header) new BasicHeader("Cache-Control", "no-cache"));
		httpRequest.addHeader((Header) new BasicHeader("Pragma", "no-cache"));

		HttpResponse httpResponse = proxy.execute((HttpRequestBase) httpRequest, httpClientContext);

		return httpResponse;
	}

}
